package org.student.fancyAppv0;


public interface SomeInterface {

    void someMethod();

}
