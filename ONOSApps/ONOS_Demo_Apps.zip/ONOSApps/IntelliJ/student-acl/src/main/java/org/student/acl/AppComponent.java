/*
 * Copyright 2016 Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.student.acl;

// Imports from scheleton app

import org.onosproject.cfg.ComponentConfigService;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//

//Original imports
//
// import org.apache.felix.scr.annotations.*;
import org.onlab.packet.*;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.DeviceId;
import org.onosproject.net.Host;
import org.onosproject.net.Port;
import org.onosproject.net.PortNumber;
import org.onosproject.net.flow.*;
import org.onosproject.net.flowobjective.DefaultForwardingObjective;
import org.onosproject.net.flowobjective.FlowObjectiveService;
import org.onosproject.net.flowobjective.ForwardingObjective;
import org.onosproject.net.packet.*;
import java.util.*;

//import java.util.Dictionary;
//import java.util.Properties;

import static org.onlab.util.Tools.get;
import java.lang.*;


@Component(immediate = true,
        service = {SomeInterface.class},
        property = {
                "someProperty=Some Default String Value",
        })
public class AppComponent implements SomeInterface {
    private final Logger log = LoggerFactory.getLogger(getClass());

    /** Some configurable property. */
    private String someProperty;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected ComponentConfigService cfgService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected PacketService packetService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected FlowRuleService flowRuleService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected FlowObjectiveService flowObjectiveService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected CoreService coreService;

    private ReactivePacketProcessor processor = new ReactivePacketProcessor();

    private ApplicationId appId;

    ArrayList<TrafficSelector> aclRules  =  new ArrayList<>();

    @org.osgi.service.component.annotations.Activate
    protected void activate() {
        cfgService.registerProperties(getClass());
        appId = coreService.registerApplication("org.student.acl");
        packetService.addProcessor(processor, PacketProcessor.director(1));
        //Specify a priority of 1 in our packet processor, so we handle the packets before the Forwarding app.
        defineAclRules();
        log.info("***** ACL: Started*****", appId.id());
    }

    @org.osgi.service.component.annotations.Deactivate
    protected void deactivate() {
        cfgService.unregisterProperties(getClass(), false);
        flowRuleService.removeFlowRulesById(appId);
        packetService.removeProcessor(processor);
        processor = null;
        log.info("***** ACL: Stopped");
    }

    @org.osgi.service.component.annotations.Modified
    public void modified(ComponentContext context) {
        Dictionary<?, ?> properties = context != null ? context.getProperties() : new Properties();
        if (context != null) {
            someProperty = get(properties, "someProperty");
        }
        log.info("Reconfigured");
    }

    @Override
    public void someMethod() {
        log.info("Invoked");
    }
    /**
     * Use this function to define custom ACL rules and push them in the aclRules ArrayList.
     * This function is called on activate().
     */
    public void defineAclRules(){
        TrafficSelector.Builder selectorBuilder = DefaultTrafficSelector.builder();
        selectorBuilder.matchEthType(Ethernet.TYPE_IPV4);
        selectorBuilder.matchIPDst(IpPrefix.valueOf(IpAddress.valueOf("10.0.0.2"),IpPrefix.MAX_INET_MASK_LENGTH));
        selectorBuilder.matchIPProtocol(IPv4.PROTOCOL_TCP);
        selectorBuilder.matchTcpDst(TpPort.tpPort(23));
        aclRules.add(selectorBuilder.build());
        log.info("***** ACL: ACL Rules defined");
    }

    /**
     * Our custom Packet Processor, which overrides the default  process() function.
     */
    private class ReactivePacketProcessor implements PacketProcessor {

        @Override
        public void process(PacketContext context) {
            log.info("***** ACL: A packet is received");
            InboundPacket pkt = context.inPacket();
            Ethernet ethPkt = pkt.parsed();

            //Discard if  packet is null.
            if (ethPkt == null) {
                log.info("***** ACL: The parsed packet is null");
                return;
            }

            IPv4 ipv4Packet;
            //We only care for IPv4 packets, discard the rest.
            switch (EthType.EtherType.lookup(ethPkt.getEtherType())) {
                case IPV4:
                    log.info("***** ACL: It is an IPv4 packet");
                    ipv4Packet = (IPv4) ethPkt.getPayload();
                    break;
                default:
                    log.info("***** ACL: It is not an IPv4 packet - we do not do anything");
                    return;
            }
            //Generate the traffic selector based on the packet that arrived.
            TrafficSelector.Builder packetSelector = DefaultTrafficSelector.builder();
            packetSelector.matchEthType(Ethernet.TYPE_IPV4);
            packetSelector.matchIPProtocol(ipv4Packet.getProtocol());
            packetSelector.matchIPDst(IpPrefix.valueOf(IpAddress.valueOf(ipv4Packet.getDestinationAddress()),IpPrefix.MAX_INET_MASK_LENGTH));
            log.info("***** ACL: Packet selector created for this type of packets");
            //Handle TCP packets here.
            if (ipv4Packet.getProtocol() == IPv4.PROTOCOL_TCP) {
                TCP tcpPkt = (TCP) ipv4Packet.getPayload();
                packetSelector.matchTcpDst(TpPort.tpPort(tcpPkt.getDestinationPort()));
                log.info("***** ACL: TCP case managed");
            }
            //Handle UPD packets here.
            else if (ipv4Packet.getProtocol() == IPv4.PROTOCOL_UDP) {
                UDP udpPkt = (UDP) ipv4Packet.getPayload();
                packetSelector.matchUdpDst(TpPort.tpPort(udpPkt.getDestinationPort()));
                log.info("***** ACL: UDP case managed");
            }

            // If the current packet's selector matches any of the ACL rules, DROP the packet and its flow.
            for (TrafficSelector selector:aclRules){
                if (selector.equals(packetSelector.build())){
                    log.info("***** ACL: There is a matching entry in the ACL");
                    log.info("***** ACL: Therfore the Flow should be dropped");
                    dropFlow(packetSelector.build(),context);
                    context.block();    //Since we already handled the packet, BLOCK any access to it by other ONOS apps (e.g. the Forwarding app)
                    return;
                }
            }
        }
        /**
         * This function creates and install the DROP rule for the specified flow
         * @param selector
         * @param context
         */
        public void dropFlow(TrafficSelector selector,PacketContext context){
            log.info("***** ACL: Creating the FlowObjective to drop these packets");
            TrafficTreatment treatment = DefaultTrafficTreatment.builder().drop().build();
            ForwardingObjective forwardingObjective = DefaultForwardingObjective.builder()
                    .withSelector(selector)
                    .withTreatment(treatment)
                    .withPriority(1000)
                    .withFlag(ForwardingObjective.Flag.VERSATILE)
                    .fromApp(appId)
                    .makeTemporary(5)
                    .add();
            flowObjectiveService.forward(context.inPacket().receivedFrom().deviceId(), forwardingObjective);
            log.info("***** ACL: Flow Objective sent to Switch");
            return;
        }
    }
}