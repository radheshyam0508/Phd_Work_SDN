package org.student.fancyApp;


public interface SomeInterface {

    void someMethod();

}
