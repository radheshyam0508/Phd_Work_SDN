/*
 * Copyright 2016 Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.student.fancyApp;

// Imports from scheleton app

import org.onosproject.cfg.ComponentConfigService;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//

//Original imports
//import org.apache.felix.scr.annotations.*;
import org.onlab.packet.*;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.DeviceId;
import org.onosproject.net.Host;
import org.onosproject.net.Port;
import org.onosproject.net.PortNumber;
import org.onosproject.net.flow.*;
import org.onosproject.net.flowobjective.DefaultForwardingObjective;
import org.onosproject.net.flowobjective.FlowObjectiveService;
import org.onosproject.net.flowobjective.ForwardingObjective;
import org.onosproject.net.packet.*;


import java.util.Dictionary;
import java.util.Properties;

import static org.onlab.util.Tools.get;

//
//

@Component(immediate = true,
        service = {SomeInterface.class},
        property = {
                "someProperty=Some Default String Value",
        })
public class AppComponent implements SomeInterface {
    private final Logger log = LoggerFactory.getLogger(getClass());

    /** Some configurable property. */
    private String someProperty;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected ComponentConfigService cfgService;

    //private ApplicationId appId;
    private ApplicationId appId;

    private static String H1_MAC = "00:00:00:00:00:01";
    private static String H2_MAC = "00:00:00:00:00:02";
//    private static String H3_MAC = "00:00:00:00:00:03";
    private static String S1_ID = "of:0000000000000001";
    private static long H1_S1_PORT = 1;
    private static long H2_S1_PORT = 2;
//    private static long H3_S1_PORT = 3;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected CoreService coreService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    FlowObjectiveService flowObjectiveService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected FlowRuleService flowRuleService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected PacketService packetService;

    private ReactivePacketProcessor processor = new ReactivePacketProcessor();

    @Activate
    protected void activate() {
        cfgService.registerProperties(getClass());
        log.info("*********  FA  Started    ********");
        TrafficSelector.Builder selector = DefaultTrafficSelector.builder();
        selector.matchEthType(Ethernet.TYPE_IPV4);
        appId = coreService.registerApplication("org.student.fancyApp");
        packetService.requestPackets(selector.build(), PacketPriority.REACTIVE, appId);
        packetService.addProcessor(processor, PacketProcessor.director(2));
    }

    @Deactivate
    protected void deactivate() {
        cfgService.unregisterProperties(getClass(), false);
        TrafficSelector.Builder selector = DefaultTrafficSelector.builder();
        selector.matchEthType(Ethernet.TYPE_IPV4);
        packetService.cancelPackets(selector.build(), PacketPriority.REACTIVE, appId);
        flowRuleService.removeFlowRulesById(appId);
        packetService.removeProcessor(processor);
        processor = null;
        log.info("*********  FA  Stopped    ********");
    }

    @Modified
    public void modified(ComponentContext context) {
        Dictionary<?, ?> properties = context != null ? context.getProperties() : new Properties();
        if (context != null) {
            someProperty = get(properties, "someProperty");
        }
        log.info("Reconfigured");
    }

    @Override
    public void someMethod() {
        log.info("Invoked");
    }

    private class ReactivePacketProcessor implements PacketProcessor {
        @Override
        public void process(PacketContext context) {
            InboundPacket pkt = context.inPacket();
            Ethernet ethPkt = pkt.parsed();
            //Discard if packet is null.
            log.info("*** FA: Packet received");
            if (ethPkt == null) { log.info("*** FA: null packet");return;}
            // We care only for IPV4 packets, discard the rest. ARP is handled by the proxyARP app of ONOS.
            log.info("*** FA: packet is not null");
            if ((ethPkt.getEtherType()) == (Ethernet.TYPE_IPV4)){
                log.info("*** FA: IPv4 packet");
                TrafficTreatment.Builder treatmentBuilder = DefaultTrafficTreatment.builder();
                String dstMac=null;
                PortNumber outPort = null;
                // Set the dstMAC and outPort
                if (ethPkt.getDestinationMAC().toString().equals(H2_MAC)) {
                    log.info("*** FA: It is for H2");
                    log.info("*** FA: Forwarding packet to H2");
                    dstMac = H2_MAC;
                    outPort = PortNumber.portNumber(H2_S1_PORT);
                    treatmentBuilder.setOutput(outPort).build();
                } else if (ethPkt.getDestinationMAC().toString().equals(H1_MAC)) {
                    log.info("*** FA: Forwarding packet to H1");
                    dstMac = H1_MAC;
                    outPort = PortNumber.portNumber(H1_S1_PORT);
                    treatmentBuilder.setOutput(outPort).build();
                }
//                else if (ethPkt.getDestinationMAC().toString().equals(H3_MAC)){
//                    log.info("Forwarding packet to H3");
//                    dstMac = H3_MAC;
//                    outPort = PortNumber.portNumber(H3_S1_PORT);
//                    treatmentBuilder.setOutput(outPort).build();
//                }
                else{
                    log.info("*** FA: Unknown destination host, ignoring");
                    return;
                }
                //Then define WHICH traffic we want to process
                log.info("*** FA: defining traffic selector");
                TrafficSelector.Builder trafficSelectorBuilder = DefaultTrafficSelector.builder();
                trafficSelectorBuilder.matchEthDst(ethPkt.getDestinationMAC());
                //Finally generate the flow objective and push it to the switch
                log.info("*** FA: creating flow objective");
                ForwardingObjective forwardingObjective = DefaultForwardingObjective.builder()
                        .withSelector(trafficSelectorBuilder.build())
                        .withTreatment(treatmentBuilder.build())
                        .withPriority(100)
                        .withFlag(ForwardingObjective.Flag.VERSATILE)
                        .fromApp(appId)
                        .makeTemporary(5)
                        .add();
                flowObjectiveService.forward(DeviceId.deviceId(S1_ID),forwardingObjective);
                log.info("*** FA: Flow Objective sent to Switch");
                context.treatmentBuilder().addTreatment(treatmentBuilder.build());
                context.send();
                log.info("*** FA: Initial packet forwarded");
            }
            else {
                log.info("*** FA: not an IPv4 packet");
                log.info("*** FA: Thernet Type: " + String.valueOf(ethPkt.getEtherType()));
                return;
            }
        }
    }
}
