package org.student.fancyApp;

public abstract class SomeInterface {
    abstract void someMethod();
}
