/*
 * Copyright 2016-present Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.student.myhosts;

import org.apache.felix.scr.annotations.*;
import org.onosproject.net.Host;
import org.onosproject.net.host.HostEvent;
import org.onosproject.net.host.HostListener;
import org.onosproject.net.host.HostService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Component(immediate = true)
public class AppComponent {

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected HostService hostService;

    private final Logger log = LoggerFactory.getLogger(getClass());

    private final HostListener hostListener = new InternalHostListener();

    @Activate
    protected void activate() {
        log.info("myhosts: Started");
        hostService.addListener(hostListener);
    }

    @Deactivate
    protected void deactivate() {
        log.info("myhosts: Stopped");
        hostService.removeListener(hostListener);
    }


    private class InternalHostListener implements HostListener{

        @Override
        public void event(HostEvent hostEvent) {

            log.info("myhosts: New host event recorded");
            log.info("myhosts: There are {} hosts connected in the network",hostService.getHostCount());
            for (Host host:hostService.getHosts()){
                log.info("myhosts: Host {} is connected to device {}",host.toString(),host.location().deviceId());
            }
        }
    }

}
