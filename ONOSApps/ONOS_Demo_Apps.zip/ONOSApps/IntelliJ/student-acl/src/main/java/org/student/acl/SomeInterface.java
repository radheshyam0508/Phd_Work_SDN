package org.student.acl;


public interface SomeInterface {

    void someMethod();

}
