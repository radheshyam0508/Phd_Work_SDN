package org.student.virtnetwork2;


public interface SomeInterface {

    void someMethod();

}
