/*
 * Copyright 2016 Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.student.intentApp;

//import org.apache.felix.scr.annotations.*;
import org.onlab.packet.*;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.*;
import org.onosproject.net.flow.*;
import org.onosproject.net.host.HostService;
import org.onosproject.net.intent.*;
import org.onosproject.net.packet.*;
import org.slf4j.Logger;

import static org.onlab.util.Tools.get;
import static org.slf4j.LoggerFactory.getLogger;
//

import org.onosproject.cfg.ComponentConfigService;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;

import org.slf4j.LoggerFactory;

import java.util.Dictionary;
import java.util.Properties;
//

@Component(immediate = true,
        service = {SomeInterface.class},
        property = {
                "someProperty=Some Default String Value",
        })
public class AppComponent implements SomeInterface {
    private final Logger log = LoggerFactory.getLogger(getClass());

    /** Some configurable property. */
    private String someProperty;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected ComponentConfigService cfgService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected PacketService packetService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected CoreService coreService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected IntentService intentService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected FlowRuleService flowRuleService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected HostService hostService;
    private ReactivePacketProcessor processor = new ReactivePacketProcessor();

    private ApplicationId appId;

    @org.osgi.service.component.annotations.Activate
    protected void activate() {
        cfgService.registerProperties(getClass());
        appId = coreService.registerApplication("org.student.intentApp");
        packetService.addProcessor(processor, PacketProcessor.director(2));
        log.info("***** IntentApp:   Started *******", appId.id());
    }
    @org.osgi.service.component.annotations.Deactivate
    protected void deactivate() {
        cfgService.unregisterProperties(getClass(), false);
        flowRuleService.removeFlowRulesById(appId);
        packetService.removeProcessor(processor);
        processor = null;
        for (Intent intent:intentService.getIntents()) {
            intentService.withdraw(intent);
        }
        log.info("Stopped");
    }
    @org.osgi.service.component.annotations.Modified
    public void modified(ComponentContext context) {
        Dictionary<?, ?> properties = context != null ? context.getProperties() : new Properties();
        if (context != null) {
            someProperty = get(properties, "someProperty");
        }
        log.info("Reconfigured");
    }

    @Override
    public void someMethod() {
        log.info("Invoked");
    }
    private class ReactivePacketProcessor implements PacketProcessor {

        @Override
        public void process(PacketContext context) {
            InboundPacket pkt = context.inPacket();
            Ethernet ethPkt = pkt.parsed();
            //Discard if  packet is null.
            log.info("***** IntentApp:   Packet arrived  *******");
            if (ethPkt == null) {

                log.info("***** IntentApp:   Packet is null  *******");
                return;
            }

            HostId host1 = HostId.hostId(ethPkt.getSourceMAC());
            HostId host2 = HostId.hostId(ethPkt.getDestinationMAC());
            if (hostService.getHost(host1)==null) return;
            if (hostService.getHost(host2)==null) return;
            log.info("***** IntentApp:   Intent Hosts identified  *******");
            TrafficSelector selector = DefaultTrafficSelector.emptySelector();
            TrafficTreatment treatment = DefaultTrafficTreatment.emptyTreatment();
            Key key;
            if (host1.toString().compareTo(host2.toString()) < 0) {
                key = Key.of(host1.toString() + host2.toString(), appId);
            } else {
                key = Key.of(host2.toString() + host1.toString(), appId);
            }
            log.info("***** IntentApp:   Intent Key created *******");

            HostToHostIntent hostIntent = HostToHostIntent.builder()
                    .appId(appId)
                    .key(key)
                    .one(host1)
                    .two(host2)
                    .selector(selector)
                    .treatment(treatment)
                    .build();

            /*PointToPointIntent pointIntent = PointToPointIntent.builder()
                    .appId(appId)
                    .key(key)
                    .filteredIngressPoint()
                    .selector(selector)
                    .treatment(treatment)
                    .build();
                    */
            log.info("***** IntentApp:   Intent Defined  *******");
            intentService.submit(hostIntent);
            log.info("***** IntentApp:   Intent flows set in switches  *******");

        }
    }
}
