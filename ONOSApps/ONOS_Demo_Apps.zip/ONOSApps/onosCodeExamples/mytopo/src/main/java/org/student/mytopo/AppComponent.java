/*
 * Copyright 2016-present Open Networking Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.student.mytopo;

import org.apache.felix.scr.annotations.*;
import org.onosproject.net.topology.Topology;
import org.onosproject.net.topology.TopologyEvent;
import org.onosproject.net.topology.TopologyListener;
import org.onosproject.net.topology.TopologyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Component(immediate = true)
public class AppComponent {

    @Reference(cardinality = ReferenceCardinality.MANDATORY_UNARY)
    protected TopologyService topologyService;

    Topology topo;

    private final Logger log = LoggerFactory.getLogger(getClass());

    private final TopologyListener topologyListener = new InternalTopologyListener();

    @Activate
    protected void activate() {

        log.info("mytopo: Started");
        topologyService.addListener(topologyListener);
    }

    @Deactivate
    protected void deactivate() {

        log.info("mytopo: Stopped");
        topologyService.removeListener(topologyListener);
    }

    private class InternalTopologyListener implements TopologyListener {
        @Override
        public void event(TopologyEvent event) {
            log.info("mytopo: New topology event recorded");
            if (topo == null){
                topo = topologyService.currentTopology();
                log.info("mytopo: New topology is {}", String.valueOf(topologyService.currentTopology()));
                return;
            }
            if (topologyService.isLatest(topo)) {
                log.info("mytopo: Topology is unchanged");
            }
            else {
                log.info("mytopo: New topology is {}", String.valueOf(topologyService.currentTopology()));
            }
            topo = topologyService.currentTopology();

        }
    }
}
