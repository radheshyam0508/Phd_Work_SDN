package org.student.lb;


public interface SomeInterface {

    void someMethod();

}
