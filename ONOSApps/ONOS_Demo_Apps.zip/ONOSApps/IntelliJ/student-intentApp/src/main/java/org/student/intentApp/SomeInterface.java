package org.student.intentApp;


public interface SomeInterface {

    void someMethod();

}
